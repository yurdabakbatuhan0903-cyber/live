
// Basit TensorFlow modeli örneği
const tf = require('@tensorflow/tfjs-node');

let model;

async function trainModel(data) {
  const xs = tf.tensor2d(data.map(d => [d.amount, d.risk]));
  const ys = tf.tensor2d(data.map(d => [d.success]));

  model = tf.sequential();
  model.add(tf.layers.dense({ units: 10, inputShape: [2], activation: 'relu' }));
  model.add(tf.layers.dense({ units: 1, activation: 'sigmoid' }));
  model.compile({ optimizer: 'adam', loss: 'binaryCrossentropy', metrics: ['accuracy'] });

  await model.fit(xs, ys, { epochs: 20 });
}

async function predict(input) {
  if (!model) throw new Error("Model henüz eğitilmedi");
  const inputTensor = tf.tensor2d([[input.amount, input.risk]]);
  const prediction = model.predict(inputTensor);
  return prediction.dataSync()[0];
}

module.exports = { trainModel, predict };
