
// AI Tabanlı Yatırım Simülatörü (BTC Al/Sat Sinyali Üretimi)
// Bu sürüm test verisiyle çalışır; ileride gerçek API entegre edilebilir.

let portfolio = {
  usdt: 1000,
  btc: 0,
  history: [],
};

let lastPrice = 50000; // Simülasyon için başlangıç BTC fiyatı

// Basit fiyat simülasyonu (gerçek API yerine dummy veri)
function getSimulatedPrice() {
  const fluctuation = (Math.random() - 0.5) * 1000; // +/- 500 USD aralığında oynama
  lastPrice = Math.max(10000, lastPrice + fluctuation);
  return lastPrice;
}

// Basit sinyal üretici: fiyat yükseliyorsa al, düşüyorsa sat
function generateSignal(currentPrice) {
  if (portfolio.history.length < 3) return "HOLD";

  const recentPrices = portfolio.history.slice(-3).map(h => h.price);
  const avg = recentPrices.reduce((a, b) => a + b, 0) / recentPrices.length;

  if (currentPrice > avg * 1.01) return "BUY";
  if (currentPrice < avg * 0.99) return "SELL";
  return "HOLD";
}

function runSimulationStep() {
  const price = getSimulatedPrice();
  const action = generateSignal(price);

  if (action === "BUY" && portfolio.usdt >= price) {
    const amount = portfolio.usdt / price;
    portfolio.btc += amount;
    portfolio.usdt = 0;
    portfolio.history.push({ action: "BUY", price, btc: portfolio.btc, usdt: portfolio.usdt });
  } else if (action === "SELL" && portfolio.btc > 0) {
    const proceeds = portfolio.btc * price;
    portfolio.usdt = proceeds;
    portfolio.btc = 0;
    portfolio.history.push({ action: "SELL", price, btc: portfolio.btc, usdt: portfolio.usdt });
  } else {
    portfolio.history.push({ action: "HOLD", price, btc: portfolio.btc, usdt: portfolio.usdt });
  }

  return {
    action,
    price,
    btc: portfolio.btc,
    usdt: portfolio.usdt,
    history: portfolio.history.slice(-10), // son 10 adımı gönder
  };
}

module.exports = { runSimulationStep };
