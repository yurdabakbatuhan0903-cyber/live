
import React, { useState } from 'react';

const LiveSimulator = () => {
  const [investment, setInvestment] = useState({
    amount: '',
    sector: '',
    risk: '',
  });

  const handleChange = (e) => {
    setInvestment({ ...investment, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const res = await fetch('/api/investments/simulate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(investment),
    });
    const data = await res.json();
    alert(`AI Tahmini: ${data.prediction}`);
  };

  return (
    <form onSubmit={handleSubmit}>
      <input name="amount" placeholder="Yatırım Tutarı" onChange={handleChange} />
      <input name="sector" placeholder="Sektör" onChange={handleChange} />
      <input name="risk" placeholder="Risk Seviyesi" onChange={handleChange} />
      <button type="submit">Simüle Et</button>
    </form>
  );
};

export default LiveSimulator;
